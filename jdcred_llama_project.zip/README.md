
# 🤖 JD CRED AI Assistant (LLaMA 4)

Este projeto tem como objetivo criar um assistente virtual inteligente para a JD CRED, utilizando o modelo LLaMA 4 da Meta, hospedado e gerenciado por meio da API da Together.ai. A IA é treinada semanalmente com exemplos reais de atendimento, garantindo um suporte eficiente e personalizado para clientes da agência.

## 🚀 Funcionalidades

- Recepção automatizada de clientes via WhatsApp ou web
- Identificação do tipo de atendimento: financeiro ou impressão
- Coleta de dados de clientes
- Encaminhamento automático para atendimento humano
- Treinamento contínuo da IA via GitHub (aprendizado manual com base nos atendimentos reais)

## 🛠️ Tecnologias

- `LLaMA 4` (API Together.ai)
- `Python` + `FastAPI` (para backend local ou servidor)
- `GitHub` (controle de versão e base de dados de exemplos)
- `Render` ou outro provedor (para deploy futuro)

## 🧠 Treinamento da IA

Toda semana, exemplos reais de atendimento serão salvos em arquivos `.json` e utilizados para alimentar o contexto do modelo via API.

## 📁 Estrutura do Projeto

```
/data/
    atendimentos-exemplo.json
    respostas-personalizadas.json
/models/
    prompt_base.txt
app.py
.gitignore
README.md
```

## 📡 API de Inferência (via Together.ai)

Você pode testar interações com o modelo diretamente pelo Playground da Together:
👉 [Playground LLaMA 4 Maverick](https://api.together.ai/playground/v2/chat/meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8)

## ⚠️ Licença

Este projeto é privado. Todos os direitos reservados à JD CRED.
